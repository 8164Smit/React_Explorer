import "./App.css";
import JSXDemo from "./components/JSXDemo";
import PropsStateDemo from "./components/PropsStateDemo";
import ListDemo from "./components/ListDemo";
import FormDemo from "./components/FormDemo";
import EffectDemo from "./components/EffectDemo";
import ClassDemo from "./components/ClassDemo";

export default function App() {
  return (
    <>
      <h1 className="main-title">React Explorer - All Modules</h1>

      <div className="section">
        <h2>1. JSX Demo</h2>
        <JSXDemo />
      </div>

      <div className="section">
        <h2>2. Props & State Demo</h2>
        <PropsStateDemo />
      </div>

      <div className="section">
        <h2>3. List Rendering Demo</h2>
        <ListDemo />
      </div>

      <div className="section">
        <h2>4. Forms Demo</h2>
        <FormDemo />
      </div>

      <div className="section">
        <h2>5. useEffect Demo</h2>
        <EffectDemo />
      </div>

      <div className="section">
        <h2>6. Class Component Demo</h2>
        <ClassDemo />
      </div>
    </>
  );
}
