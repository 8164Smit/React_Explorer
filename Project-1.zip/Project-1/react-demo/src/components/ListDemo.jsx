import { useState } from "react";

export default function ListDemo() {
    const [list, setList] = useState(["Apple", "Mango", "Orange"]);
    const [search, setSearch] = useState("");

    const filtered = list.filter(item =>
        item.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div>

            <input
                placeholder="search..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
            />

            <ul>
                {filtered.map((item, index) => (
                    <li key={index}>{item}</li>
                ))}
            </ul>
        </div>
    );
}
