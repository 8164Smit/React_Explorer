import { useState } from "react";

function Message({ text }) {
    return <p style={{ marginTop: "5px" }}>Message: {text}</p>;
}

export default function PropsStateDemo() {
    const [count, setCount] = useState(0);

    return (
        <div>

            <button
                className="btn-blue"
                onClick={() => setCount(count + 1)}
            >
                Increase
            </button>

            <button
                className="btn-red"
                onClick={() => setCount(count - 1)}
            >
                Decrease
            </button>

            <Message text={`Current Count is ${count}`} />
        </div>
    );
}
