import { Component } from "react";

export default class ClassDemo extends Component {
    constructor() {
        super();
        this.state = { clicks: 0 };
    }

    render() {
        return (
            <div className="class-box">

                <button className="my-btn"
                    onClick={() => this.setState({ clicks: this.state.clicks + 1 })}>
                    Click
                </button>

                <p className="click-text">Clicks: {this.state.clicks}</p>
            </div>
        );
    }
}
