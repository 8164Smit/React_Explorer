export default function JSXDemo() {
    const name = "Jinkal Mam";
    return (
        <div>
            {/* <h2>JSX Basics</h2> */}
            <p>Hello, {name}! This is simple JSX rendering.</p>
            <p>2 + 3 = {2 + 3}</p>
        </div>
    );
}
