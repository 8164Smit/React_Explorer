import { useEffect, useState } from "react";

export default function EffectDemo() {
    const [num, setNum] = useState(0);

    useEffect(() => {
        console.log("Number updated to:", num);
    }, [num]);

    return (
        <div className="effect-box">

            <button className="my-btn" onClick={() => setNum(num + 1)}>Increase</button>

            <p className="num-text">Value: {num}</p>
        </div>
    );
}
